// Inicialización
document.addEventListener('DOMContentLoaded', () => {
  initializeStorage();
  updateVoteDisplay();
});